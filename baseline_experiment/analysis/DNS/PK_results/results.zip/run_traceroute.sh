cd ./step4_traceroute
python collect_traceroute.py ./domains_ns.txt



