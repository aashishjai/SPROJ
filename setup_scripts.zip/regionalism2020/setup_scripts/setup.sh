# Install python 3 and make it the default
sudo apt install python3.7
sudo update-alternatives --install /usr/bin/python python /usr/bin/python3.7 1
sudo update-alternatives --config python

# Set up the BIND server
sudo apt update
sudo apt-get remove bind9 -y
sudo apt-get remove --purge bind9 -y
sudo apt-get update -y
sudo apt-get install bind9 bind9utils bind9-doc -y
cd /etc/bind
echo "acl goodclients {
    192.0.2.0/24;
    localhost;
    localnets;
};

options {
	directory \"/var/cache/bind\";
	recursion yes;
    	allow-query { goodclients; };
	// If there is a firewall between you and nameservers you want
	// to talk to, you may need to fix the firewall to allow multiple
	// ports to talk.  See http://www.kb.cert.org/vuls/id/800113

	// If your ISP provided one or more IP addresses for stable 
	// nameservers, you probably want to use them as forwarders.  
	// Uncomment the following block, and insert the addresses replacing 
	// the all-0's placeholder.

	// forwarders {
	// 	0.0.0.0;
	// };
	dnssec-validation no;
	//========================================================================
	// If BIND logs error messages about the root key being expired,
	// you will need to update your keys.  See https://www.isc.org/bind-keys
	//========================================================================
//	dnssec-validation auto;
	auth-nxdomain no;    # conform to RFC1035
//	listen-on-v6 { any; };
};" > named.conf.options

echo "// This is the primary configuration file for the BIND DNS server named.
//
// Please read /usr/share/doc/bind9/README.Debian.gz for information on the 
// structure of BIND configuration files in Debian, *BEFORE* you customize 
// this configuration file.
//
// If you are just adding zones, please do that in /etc/bind/named.conf.local

include \"/etc/bind/named.conf.options\";
include \"/etc/bind/named.conf.local\";
include \"/etc/bind/named.conf.default-zones\";

server ::/0 {
       edns no;

};

server 0.0.0.0/0 {
       edns no;

};" > named.conf
echo "# run resolvconf?
RESOLVCONF=no

# startup options for the server
OPTIONS=\"-4 -u bind\"" > /etc/default/bind9
named-checkconf
sudo service bind9 restart

sudo apt-get install -y zip screen dnsutils sshpass expect python-setuptools python3-setuptools tcpdump

# Setup DNS Python
sudo apt install git
git clone https://github.com/rthalley/dnspython
cd dnspython/
pip install --upgrade pip build
python -m build
pip install dist/*.whl
cd ..

# Set up Python Scapy - changes made here
git clone https://github.com/secdev/scapy.git
cd scapy
pip install .

sudo apt install -y tshark