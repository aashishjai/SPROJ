step 1 : in all control countries, run DNS_pipeline_step2 by 
running "bash proximity.sh" 

step 2 : wait for a time until script completes. 
time we need to wait depends on number of domains and gap limit

step 3 : run bash data.sh
